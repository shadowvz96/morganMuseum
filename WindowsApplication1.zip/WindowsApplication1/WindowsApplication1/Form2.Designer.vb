﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.pbox2 = New System.Windows.Forms.PictureBox()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.btn1 = New System.Windows.Forms.Button()
        CType(Me.pbox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.BackColor = System.Drawing.Color.Transparent
        Me.lbl1.Font = New System.Drawing.Font("Lucida Handwriting", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.ForeColor = System.Drawing.SystemColors.Control
        Me.lbl1.Location = New System.Drawing.Point(66, 59)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(520, 37)
        Me.lbl1.TabIndex = 6
        Me.lbl1.Text = "Welcome to Morgan Kiosk v1.0!"
        '
        'pbox2
        '
        Me.pbox2.BackColor = System.Drawing.Color.White
        Me.pbox2.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.morgan
        Me.pbox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbox2.Location = New System.Drawing.Point(195, 99)
        Me.pbox2.Name = "pbox2"
        Me.pbox2.Size = New System.Drawing.Size(281, 191)
        Me.pbox2.TabIndex = 7
        Me.pbox2.TabStop = False
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.BackColor = System.Drawing.Color.Transparent
        Me.lbl2.Font = New System.Drawing.Font("Lucida Handwriting", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2.ForeColor = System.Drawing.SystemColors.Control
        Me.lbl2.Location = New System.Drawing.Point(32, 293)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(610, 37)
        Me.lbl2.TabIndex = 8
        Me.lbl2.Text = "To Login as Guest, Click Login Below"
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("Lucida Handwriting", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.Location = New System.Drawing.Point(195, 342)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(289, 59)
        Me.btn1.TabIndex = 10
        Me.btn1.Text = "Login As Guest"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.tablet
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(676, 515)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.pbox2)
        Me.Controls.Add(Me.lbl1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        CType(Me.pbox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend lbl2 As System.Windows.Forms.Label
    Friend pbox2 As System.Windows.Forms.PictureBox
    Friend lbl1 As System.Windows.Forms.Label
    Friend WithEvents btn1 As Button
End Class
