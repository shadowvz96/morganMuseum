﻿Public Class Form3
    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        Dim form2 As New Form2
        form2.Show()
        Me.Hide()
        pbox4.Visible = False
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbox4.Visible = True
        btn_exit1.Visible = True
        pbox4.BringToFront()
        btn_exit1.BringToFront()

    End Sub

    Private Sub btn_exit1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btn_exit1.Visible = False
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        btn_exit1.Visible = True
        pbox5.Visible = True
        pbox5.BringToFront()
        btn_exit1.BringToFront()
    End Sub

    Private Sub btn_exit1_Click_1(sender As Object, e As EventArgs) Handles btn_exit1.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbox4.Visible = False
        pbox5.Visible = False
        pbox7.Visible = False
        pbox8.Visible = False
        pbox10.Visible = False
        btn_exit1.Visible = False
        pbgal1.Visible = False
        pbgal2.Visible = False
        pbgal3.Visible = False
        mmorganS.Visible = False
        pbliboff.Visible = False
        pbrot.Visible = False
        pbstudy.Visible = False
    End Sub

    Private Sub btn_f1_Click(sender As Object, e As EventArgs) Handles btn_f1.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        lbl_floor.Text = "You are currently on Floor 1"
        Timer1.Interval = 3000
        Timer1.Start()
    End Sub
    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        lbl_floor.Text = ""
        Timer1.Stop()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub btn_f2_Click(sender As Object, e As EventArgs) Handles btn_f2.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        Dim form4 As New Form4
        form4.Show()
        Me.Hide()
    End Sub

    Private Sub btn_floor3_Click(sender As Object, e As EventArgs) Handles btn_floor3.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        Dim form5 As New Form5
        form5.Show()
        Me.Hide()
    End Sub

    Private Sub pbox6_Click(sender As Object, e As EventArgs) Handles pbox6.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbox7.Visible = True
        btn_exit1.Visible = True
        pbox7.BringToFront()
        btn_exit1.BringToFront()
    End Sub

    Private Sub btn_marble_Click(sender As Object, e As EventArgs) Handles btn_marble.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbox8.Visible = True
        btn_exit1.Visible = True
        pbox8.BringToFront()
        btn_exit1.BringToFront()
    End Sub

    Private Sub pbox9_Click(sender As Object, e As EventArgs) Handles pbox9.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbox10.Visible = True
        btn_exit1.Visible = True
        pbox10.BringToFront()
        btn_exit1.BringToFront()
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles pbox10.Click

    End Sub

    Private Sub gal1_Click(sender As Object, e As EventArgs) Handles gal1.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbgal1.Visible = True
        btn_exit1.Visible = True
        pbgal1.BringToFront()
        btn_exit1.BringToFront()
    End Sub

    Private Sub gal2_Click(sender As Object, e As EventArgs) Handles gal2.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbgal2.Visible = True
        btn_exit1.Visible = True
        pbgal2.BringToFront()
        btn_exit1.BringToFront()
    End Sub

    Private Sub liboff_Click(sender As Object, e As EventArgs) Handles liboff.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbliboff.Visible = True
        btn_exit1.Visible = True
        pbliboff.BringToFront()
        btn_exit1.BringToFront()
    End Sub

    Private Sub PictureBox5_Click_1(sender As Object, e As EventArgs) Handles PictureBox5.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        mmorganS.Visible = True
        btn_exit1.Visible = True
        mmorganS.BringToFront()
        btn_exit1.BringToFront()
    End Sub

    Private Sub gal3_Click(sender As Object, e As EventArgs) Handles gal3.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbgal3.Visible = True
        btn_exit1.Visible = True
        pbgal3.BringToFront()
        btn_exit1.BringToFront()
    End Sub

    Private Sub rot_Click(sender As Object, e As EventArgs) Handles rot.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbrot.Visible = True
        btn_exit1.Visible = True
        pbrot.BringToFront()
        btn_exit1.BringToFront()
    End Sub

    Private Sub study_Click(sender As Object, e As EventArgs) Handles study.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbstudy.Visible = True
        btn_exit1.Visible = True
        pbstudy.BringToFront()
        btn_exit1.BringToFront()
    End Sub
End Class