﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btn_floor3 = New System.Windows.Forms.Button()
        Me.btn_f2 = New System.Windows.Forms.Button()
        Me.btn_f1 = New System.Windows.Forms.Button()
        Me.lbl_floor = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.pbox1 = New System.Windows.Forms.PictureBox()
        Me.pbgal = New System.Windows.Forms.PictureBox()
        Me.pbegal = New System.Windows.Forms.PictureBox()
        Me.btn_exit1 = New System.Windows.Forms.Button()
        CType(Me.pbox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbgal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbegal, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_floor3
        '
        Me.btn_floor3.Location = New System.Drawing.Point(71, 414)
        Me.btn_floor3.Name = "btn_floor3"
        Me.btn_floor3.Size = New System.Drawing.Size(75, 23)
        Me.btn_floor3.TabIndex = 14
        Me.btn_floor3.Text = "Floor 3"
        Me.btn_floor3.UseVisualStyleBackColor = True
        '
        'btn_f2
        '
        Me.btn_f2.Location = New System.Drawing.Point(71, 385)
        Me.btn_f2.Name = "btn_f2"
        Me.btn_f2.Size = New System.Drawing.Size(75, 23)
        Me.btn_f2.TabIndex = 13
        Me.btn_f2.Text = "Floor 2"
        Me.btn_f2.UseVisualStyleBackColor = True
        '
        'btn_f1
        '
        Me.btn_f1.Location = New System.Drawing.Point(71, 356)
        Me.btn_f1.Name = "btn_f1"
        Me.btn_f1.Size = New System.Drawing.Size(75, 23)
        Me.btn_f1.TabIndex = 12
        Me.btn_f1.Text = "Floor 1"
        Me.btn_f1.UseVisualStyleBackColor = True
        '
        'lbl_floor
        '
        Me.lbl_floor.AutoSize = True
        Me.lbl_floor.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_floor.Location = New System.Drawing.Point(66, 328)
        Me.lbl_floor.Name = "lbl_floor"
        Me.lbl_floor.Size = New System.Drawing.Size(0, 25)
        Me.lbl_floor.TabIndex = 15
        '
        'Timer1
        '
        '
        'pbox1
        '
        Me.pbox1.BackColor = System.Drawing.Color.Transparent
        Me.pbox1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.map_floor2
        Me.pbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbox1.Location = New System.Drawing.Point(28, 57)
        Me.pbox1.Name = "pbox1"
        Me.pbox1.Size = New System.Drawing.Size(781, 410)
        Me.pbox1.TabIndex = 16
        Me.pbox1.TabStop = False
        '
        'pbgal
        '
        Me.pbgal.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.gallery
        Me.pbgal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbgal.Location = New System.Drawing.Point(568, 356)
        Me.pbgal.Name = "pbgal"
        Me.pbgal.Size = New System.Drawing.Size(60, 50)
        Me.pbgal.TabIndex = 17
        Me.pbgal.TabStop = False
        '
        'pbegal
        '
        Me.pbegal.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.engelhard_gallery
        Me.pbegal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbegal.Location = New System.Drawing.Point(200, 131)
        Me.pbegal.Name = "pbegal"
        Me.pbegal.Size = New System.Drawing.Size(411, 248)
        Me.pbegal.TabIndex = 18
        Me.pbegal.TabStop = False
        '
        'btn_exit1
        '
        Me.btn_exit1.BackColor = System.Drawing.Color.Transparent
        Me.btn_exit1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources._exit
        Me.btn_exit1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_exit1.Location = New System.Drawing.Point(583, 98)
        Me.btn_exit1.Name = "btn_exit1"
        Me.btn_exit1.Size = New System.Drawing.Size(45, 40)
        Me.btn_exit1.TabIndex = 19
        Me.btn_exit1.UseVisualStyleBackColor = False
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.tablet
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(840, 522)
        Me.Controls.Add(Me.btn_exit1)
        Me.Controls.Add(Me.pbgal)
        Me.Controls.Add(Me.btn_floor3)
        Me.Controls.Add(Me.btn_f2)
        Me.Controls.Add(Me.btn_f1)
        Me.Controls.Add(Me.pbox1)
        Me.Controls.Add(Me.lbl_floor)
        Me.Controls.Add(Me.pbegal)
        Me.Name = "Form4"
        Me.Text = "Form4"
        CType(Me.pbox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbgal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbegal, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_floor3 As Button
    Friend WithEvents btn_f2 As Button
    Friend WithEvents btn_f1 As Button
    Friend WithEvents lbl_floor As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents pbox1 As PictureBox
    Friend WithEvents pbgal As PictureBox
    Friend WithEvents pbegal As PictureBox
    Friend WithEvents btn_exit1 As Button
End Class
