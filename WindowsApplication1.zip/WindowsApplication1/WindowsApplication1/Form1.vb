﻿Public Class Form1
    Dim increment As Integer


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pbox1.Load("E:\SoftEng2017\windows.gif")

    End Sub

    Private Sub btn_power_Click(sender As Object, e As EventArgs) Handles btn_power.Click
		My.Computer.Audio.Play("E:\SoftEng2017\vista.wav.")
        pb1.PerformStep()
        increment = increment + 100
        If increment > pb1.Maximum Then
            increment = pb1.Maximum
        End If
        If increment = 100 Then
            Threading.Thread.Sleep(3000) 'ms
        End If
        pb1.Value = increment
        pb1.Visible = True
        Timer1.Interval = 3000
        Timer1.Start()
        Dim form2 as new Form2
		form2.Show()
		Me.hide()


    End Sub

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
		btn_power.Visible = False
        Timer1.Stop()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub pbox1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub WebBrowser1_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs)

    End Sub


    
    
    Sub Btn_powerClick(sender As Object, e As EventArgs)
    	
    End Sub
End Class
