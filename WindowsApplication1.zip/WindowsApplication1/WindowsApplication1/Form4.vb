﻿Public Class Form4
    Private Sub btn_f1_Click(sender As Object, e As EventArgs) Handles btn_f1.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        Dim form3 As New Form3
        form3.Show()
        Me.Hide()
    End Sub

    Private Sub btn_f2_Click(sender As Object, e As EventArgs) Handles btn_f2.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        lbl_floor.BringToFront()
        lbl_floor.Text = "You are currently on Floor 2"
        Timer1.Interval = 3000
        Timer1.Start()
    End Sub

    Private Sub btn_floor3_Click(sender As Object, e As EventArgs) Handles btn_floor3.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        Dim form5 As New Form5
        form5.Show()
        Me.Hide()
    End Sub
    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        lbl_floor.Text = ""
        Timer1.Stop()
    End Sub

    Private Sub btn_exit1_Click(sender As Object, e As EventArgs) Handles btn_exit1.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        btn_exit1.Visible = False
        pbegal.Visible = False
    End Sub

    Private Sub pbgal_Click(sender As Object, e As EventArgs) Handles pbgal.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbegal.Visible = True
        pbegal.BringToFront()
        btn_exit1.Visible = True
        btn_exit1.BringToFront()
    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btn_exit1.Visible = False
    End Sub

End Class