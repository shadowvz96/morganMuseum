﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
    	Me.components = New System.ComponentModel.Container()
    	Me.pb1 = New System.Windows.Forms.ProgressBar()
    	Me.btn_power = New System.Windows.Forms.Button()
    	Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
    	Me.pbox1 = New System.Windows.Forms.PictureBox()
    	CType(Me.pbox1,System.ComponentModel.ISupportInitialize).BeginInit
    	Me.SuspendLayout
    	'
    	'pb1
    	'
    	Me.pb1.Location = New System.Drawing.Point(26, 434)
    	Me.pb1.Name = "pb1"
    	Me.pb1.Size = New System.Drawing.Size(636, 23)
    	Me.pb1.TabIndex = 2
    	'
    	'btn_power
    	'
    	Me.btn_power.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.power
    	Me.btn_power.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
    	Me.btn_power.Location = New System.Drawing.Point(623, 463)
    	Me.btn_power.Name = "btn_power"
    	Me.btn_power.Size = New System.Drawing.Size(39, 41)
    	Me.btn_power.TabIndex = 3
    	Me.btn_power.UseVisualStyleBackColor = true
    	AddHandler Me.btn_power.Click, AddressOf Me.Btn_powerClick
    	'
    	'pbox1
    	'
    	Me.pbox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
    	    	    	Or System.Windows.Forms.AnchorStyles.Left)  _
    	    	    	Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
    	Me.pbox1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.windows
    	Me.pbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
    	Me.pbox1.Location = New System.Drawing.Point(26, 58)
    	Me.pbox1.Name = "pbox1"
    	Me.pbox1.Size = New System.Drawing.Size(636, 379)
    	Me.pbox1.TabIndex = 4
    	Me.pbox1.TabStop = false
    	'
    	'Form1
    	'
    	Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
    	Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    	Me.AutoSize = true
    	Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.tablet
    	Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
    	Me.ClientSize = New System.Drawing.Size(687, 523)
    	Me.Controls.Add(Me.pbox1)
    	Me.Controls.Add(Me.btn_power)
    	Me.Controls.Add(Me.pb1)
    	Me.MaximizeBox = false
    	Me.Name = "Form1"
    	Me.Text = "Form1"
    	CType(Me.pbox1,System.ComponentModel.ISupportInitialize).EndInit
    	Me.ResumeLayout(false)
    End Sub
    Friend WithEvents pb1 As ProgressBar
    Friend WithEvents btn_power As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents pbox1 As PictureBox
End Class
