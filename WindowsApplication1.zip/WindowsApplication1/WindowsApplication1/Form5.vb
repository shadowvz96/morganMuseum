﻿Public Class Form5
    Private Sub btn_floor3_Click(sender As Object, e As EventArgs) Handles btn_floor3.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        lbl_floor.Text = "You are currently on Floor 3"
        Timer1.Interval = 3000
        Timer1.Start()
    End Sub

    Private Sub btn_f2_Click(sender As Object, e As EventArgs) Handles btn_f2.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        Dim form4 As New Form4
        form4.Show()
        Me.Hide()
    End Sub

    Private Sub btn_f1_Click(sender As Object, e As EventArgs) Handles btn_f1.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        Dim form3 As New Form3
        form3.Show()
        Me.Hide()
    End Sub
    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        lbl_floor.Text = ""
        Timer1.Stop()
    End Sub

    Private Sub pbox3_Click(sender As Object, e As EventArgs) Handles pbox3.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbhall.Visible = True
        pbhall.BringToFront()
        btn_exit1.Visible = True
        btn_exit1.BringToFront()
    End Sub

    Private Sub btn_exit1_Click(sender As Object, e As EventArgs) Handles btn_exit1.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbhall.Visible = False
        pbed.Visible = False
        btn_exit1.Visible = False
    End Sub

    Private Sub pbox2_Click(sender As Object, e As EventArgs) Handles pbox2.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        pbed.Visible = True
        pbed.BringToFront()
        btn_exit1.Visible = True
        btn_exit1.BringToFront()
    End Sub

End Class