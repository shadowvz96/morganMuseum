﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.pbox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.pbox5 = New System.Windows.Forms.PictureBox()
        Me.btn_exit1 = New System.Windows.Forms.Button()
        Me.btn_f1 = New System.Windows.Forms.Button()
        Me.btn_f2 = New System.Windows.Forms.Button()
        Me.btn_floor3 = New System.Windows.Forms.Button()
        Me.lbl_floor = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.pbox6 = New System.Windows.Forms.PictureBox()
        Me.pbox7 = New System.Windows.Forms.PictureBox()
        Me.btn_marble = New System.Windows.Forms.Button()
        Me.pbox8 = New System.Windows.Forms.PictureBox()
        Me.pbox9 = New System.Windows.Forms.PictureBox()
        Me.pbox10 = New System.Windows.Forms.PictureBox()
        Me.gal1 = New System.Windows.Forms.PictureBox()
        Me.gal2 = New System.Windows.Forms.PictureBox()
        Me.gal3 = New System.Windows.Forms.PictureBox()
        Me.pbgal1 = New System.Windows.Forms.PictureBox()
        Me.pbgal2 = New System.Windows.Forms.PictureBox()
        Me.pbgal3 = New System.Windows.Forms.PictureBox()
        Me.pbliboff = New System.Windows.Forms.PictureBox()
        Me.liboff = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.mmorganS = New System.Windows.Forms.PictureBox()
        Me.rot = New System.Windows.Forms.PictureBox()
        Me.pbrot = New System.Windows.Forms.PictureBox()
        Me.study = New System.Windows.Forms.PictureBox()
        Me.pbstudy = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gal1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gal2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gal3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbgal1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbgal2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbgal3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbliboff, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.liboff, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mmorganS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rot, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbrot, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.study, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbstudy, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_back
        '
        Me.btn_back.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources._return
        Me.btn_back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_back.Location = New System.Drawing.Point(581, 496)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(57, 41)
        Me.btn_back.TabIndex = 0
        Me.btn_back.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.map_floor1
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(22, 56)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(630, 434)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.you_are_here_icon
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(361, 324)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(46, 38)
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.coffee
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Location = New System.Drawing.Point(265, 265)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(45, 50)
        Me.PictureBox3.TabIndex = 3
        Me.PictureBox3.TabStop = False
        '
        'pbox4
        '
        Me.pbox4.BackColor = System.Drawing.Color.Transparent
        Me.pbox4.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.cafe_new_0
        Me.pbox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbox4.Location = New System.Drawing.Point(103, 186)
        Me.pbox4.Name = "pbox4"
        Me.pbox4.Size = New System.Drawing.Size(268, 226)
        Me.pbox4.TabIndex = 4
        Me.pbox4.TabStop = False
        Me.pbox4.Visible = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox4.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.plate_fork_and_knife
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.Location = New System.Drawing.Point(208, 283)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(51, 50)
        Me.PictureBox4.TabIndex = 6
        Me.PictureBox4.TabStop = False
        '
        'pbox5
        '
        Me.pbox5.BackColor = System.Drawing.Color.Transparent
        Me.pbox5.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.cafe_new_0
        Me.pbox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbox5.Image = Global.WindowsApplication1.My.Resources.Resources.shop_bs_1000
        Me.pbox5.Location = New System.Drawing.Point(46, 240)
        Me.pbox5.Name = "pbox5"
        Me.pbox5.Size = New System.Drawing.Size(264, 226)
        Me.pbox5.TabIndex = 7
        Me.pbox5.TabStop = False
        '
        'btn_exit1
        '
        Me.btn_exit1.BackColor = System.Drawing.Color.Transparent
        Me.btn_exit1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources._exit
        Me.btn_exit1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_exit1.Location = New System.Drawing.Point(265, 76)
        Me.btn_exit1.Name = "btn_exit1"
        Me.btn_exit1.Size = New System.Drawing.Size(45, 40)
        Me.btn_exit1.TabIndex = 8
        Me.btn_exit1.UseVisualStyleBackColor = False
        '
        'btn_f1
        '
        Me.btn_f1.Location = New System.Drawing.Point(31, 239)
        Me.btn_f1.Name = "btn_f1"
        Me.btn_f1.Size = New System.Drawing.Size(75, 23)
        Me.btn_f1.TabIndex = 9
        Me.btn_f1.Text = "Floor 1"
        Me.btn_f1.UseVisualStyleBackColor = True
        '
        'btn_f2
        '
        Me.btn_f2.Location = New System.Drawing.Point(31, 268)
        Me.btn_f2.Name = "btn_f2"
        Me.btn_f2.Size = New System.Drawing.Size(75, 23)
        Me.btn_f2.TabIndex = 10
        Me.btn_f2.Text = "Floor 2"
        Me.btn_f2.UseVisualStyleBackColor = True
        '
        'btn_floor3
        '
        Me.btn_floor3.Location = New System.Drawing.Point(31, 297)
        Me.btn_floor3.Name = "btn_floor3"
        Me.btn_floor3.Size = New System.Drawing.Size(75, 23)
        Me.btn_floor3.TabIndex = 11
        Me.btn_floor3.Text = "Floor 3"
        Me.btn_floor3.UseVisualStyleBackColor = True
        '
        'lbl_floor
        '
        Me.lbl_floor.AutoSize = True
        Me.lbl_floor.BackColor = System.Drawing.SystemColors.Control
        Me.lbl_floor.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_floor.Location = New System.Drawing.Point(29, 197)
        Me.lbl_floor.Name = "lbl_floor"
        Me.lbl_floor.Size = New System.Drawing.Size(0, 25)
        Me.lbl_floor.TabIndex = 12
        '
        'Timer1
        '
        '
        'pbox6
        '
        Me.pbox6.BackColor = System.Drawing.Color.Transparent
        Me.pbox6.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.shopping_cart
        Me.pbox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbox6.Location = New System.Drawing.Point(132, 357)
        Me.pbox6.Name = "pbox6"
        Me.pbox6.Size = New System.Drawing.Size(42, 40)
        Me.pbox6.TabIndex = 13
        Me.pbox6.TabStop = False
        '
        'pbox7
        '
        Me.pbox7.BackColor = System.Drawing.Color.Transparent
        Me.pbox7.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.shop_bs_10001
        Me.pbox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbox7.Location = New System.Drawing.Point(31, 87)
        Me.pbox7.Name = "pbox7"
        Me.pbox7.Size = New System.Drawing.Size(260, 215)
        Me.pbox7.TabIndex = 14
        Me.pbox7.TabStop = False
        '
        'btn_marble
        '
        Me.btn_marble.BackColor = System.Drawing.Color.Transparent
        Me.btn_marble.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.ionic_pillar
        Me.btn_marble.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_marble.Location = New System.Drawing.Point(581, 368)
        Me.btn_marble.Name = "btn_marble"
        Me.btn_marble.Size = New System.Drawing.Size(50, 44)
        Me.btn_marble.TabIndex = 15
        Me.btn_marble.UseVisualStyleBackColor = False
        '
        'pbox8
        '
        Me.pbox8.BackColor = System.Drawing.Color.Transparent
        Me.pbox8.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.McKim_5178_2
        Me.pbox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbox8.Location = New System.Drawing.Point(112, 121)
        Me.pbox8.Name = "pbox8"
        Me.pbox8.Size = New System.Drawing.Size(331, 291)
        Me.pbox8.TabIndex = 16
        Me.pbox8.TabStop = False
        '
        'pbox9
        '
        Me.pbox9.BackColor = System.Drawing.Color.Transparent
        Me.pbox9.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.court
        Me.pbox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbox9.Location = New System.Drawing.Point(377, 230)
        Me.pbox9.Name = "pbox9"
        Me.pbox9.Size = New System.Drawing.Size(41, 39)
        Me.pbox9.TabIndex = 17
        Me.pbox9.TabStop = False
        '
        'pbox10
        '
        Me.pbox10.BackColor = System.Drawing.Color.Transparent
        Me.pbox10.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.gilbert_court_0
        Me.pbox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbox10.Location = New System.Drawing.Point(338, 87)
        Me.pbox10.Name = "pbox10"
        Me.pbox10.Size = New System.Drawing.Size(256, 172)
        Me.pbox10.TabIndex = 18
        Me.pbox10.TabStop = False
        '
        'gal1
        '
        Me.gal1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.gallery
        Me.gal1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.gal1.Location = New System.Drawing.Point(516, 278)
        Me.gal1.Name = "gal1"
        Me.gal1.Size = New System.Drawing.Size(40, 37)
        Me.gal1.TabIndex = 19
        Me.gal1.TabStop = False
        '
        'gal2
        '
        Me.gal2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.gal2.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.gallery
        Me.gal2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.gal2.Location = New System.Drawing.Point(591, 310)
        Me.gal2.Name = "gal2"
        Me.gal2.Size = New System.Drawing.Size(40, 37)
        Me.gal2.TabIndex = 20
        Me.gal2.TabStop = False
        '
        'gal3
        '
        Me.gal3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gal3.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.gallery
        Me.gal3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.gal3.Location = New System.Drawing.Point(533, 442)
        Me.gal3.Name = "gal3"
        Me.gal3.Size = New System.Drawing.Size(40, 37)
        Me.gal3.TabIndex = 21
        Me.gal3.TabStop = False
        '
        'pbgal1
        '
        Me.pbgal1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.clare_eddy_thaw_gallery
        Me.pbgal1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbgal1.Location = New System.Drawing.Point(281, 87)
        Me.pbgal1.Name = "pbgal1"
        Me.pbgal1.Size = New System.Drawing.Size(261, 204)
        Me.pbgal1.TabIndex = 22
        Me.pbgal1.TabStop = False
        '
        'pbgal2
        '
        Me.pbgal2.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.annex
        Me.pbgal2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbgal2.Location = New System.Drawing.Point(281, 87)
        Me.pbgal2.Name = "pbgal2"
        Me.pbgal2.Size = New System.Drawing.Size(328, 246)
        Me.pbgal2.TabIndex = 23
        Me.pbgal2.TabStop = False
        '
        'pbgal3
        '
        Me.pbgal3.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.annex_west
        Me.pbgal3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbgal3.Location = New System.Drawing.Point(160, 87)
        Me.pbgal3.Name = "pbgal3"
        Me.pbgal3.Size = New System.Drawing.Size(350, 347)
        Me.pbgal3.TabIndex = 24
        Me.pbgal3.TabStop = False
        '
        'pbliboff
        '
        Me.pbliboff.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.northroom
        Me.pbliboff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbliboff.Location = New System.Drawing.Point(132, 87)
        Me.pbliboff.Name = "pbliboff"
        Me.pbliboff.Size = New System.Drawing.Size(286, 215)
        Me.pbliboff.TabIndex = 25
        Me.pbliboff.TabStop = False
        '
        'liboff
        '
        Me.liboff.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.bookshelf
        Me.liboff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.liboff.Location = New System.Drawing.Point(389, 121)
        Me.liboff.Name = "liboff"
        Me.liboff.Size = New System.Drawing.Size(51, 38)
        Me.liboff.TabIndex = 26
        Me.liboff.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.PictureBox5.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.bookshelf
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.Location = New System.Drawing.Point(558, 76)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(51, 38)
        Me.PictureBox5.TabIndex = 27
        Me.PictureBox5.TabStop = False
        '
        'mmorganS
        '
        Me.mmorganS.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.mr_morgan
        Me.mmorganS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.mmorganS.Location = New System.Drawing.Point(265, 87)
        Me.mmorganS.Name = "mmorganS"
        Me.mmorganS.Size = New System.Drawing.Size(323, 217)
        Me.mmorganS.TabIndex = 28
        Me.mmorganS.TabStop = False
        '
        'rot
        '
        Me.rot.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.dome
        Me.rot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.rot.Location = New System.Drawing.Point(549, 163)
        Me.rot.Name = "rot"
        Me.rot.Size = New System.Drawing.Size(45, 39)
        Me.rot.TabIndex = 29
        Me.rot.TabStop = False
        '
        'pbrot
        '
        Me.pbrot.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.rotunda_apse
        Me.pbrot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbrot.Location = New System.Drawing.Point(281, 87)
        Me.pbrot.Name = "pbrot"
        Me.pbrot.Size = New System.Drawing.Size(292, 172)
        Me.pbrot.TabIndex = 30
        Me.pbrot.TabStop = False
        '
        'study
        '
        Me.study.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.notebook
        Me.study.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.study.Location = New System.Drawing.Point(581, 239)
        Me.study.Name = "study"
        Me.study.Size = New System.Drawing.Size(36, 36)
        Me.study.TabIndex = 31
        Me.study.TabStop = False
        '
        'pbstudy
        '
        Me.pbstudy.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.Pierpont_Morgans_Library1
        Me.pbstudy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbstudy.Location = New System.Drawing.Point(281, 87)
        Me.pbstudy.Name = "pbstudy"
        Me.pbstudy.Size = New System.Drawing.Size(328, 172)
        Me.pbstudy.TabIndex = 32
        Me.pbstudy.TabStop = False
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.tablet
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(676, 549)
        Me.Controls.Add(Me.study)
        Me.Controls.Add(Me.rot)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.liboff)
        Me.Controls.Add(Me.gal3)
        Me.Controls.Add(Me.gal2)
        Me.Controls.Add(Me.gal1)
        Me.Controls.Add(Me.pbox9)
        Me.Controls.Add(Me.btn_marble)
        Me.Controls.Add(Me.pbox6)
        Me.Controls.Add(Me.lbl_floor)
        Me.Controls.Add(Me.btn_floor3)
        Me.Controls.Add(Me.btn_f2)
        Me.Controls.Add(Me.btn_f1)
        Me.Controls.Add(Me.btn_exit1)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.pbox4)
        Me.Controls.Add(Me.pbox5)
        Me.Controls.Add(Me.pbox7)
        Me.Controls.Add(Me.pbox8)
        Me.Controls.Add(Me.pbox10)
        Me.Controls.Add(Me.pbgal1)
        Me.Controls.Add(Me.pbgal2)
        Me.Controls.Add(Me.pbgal3)
        Me.Controls.Add(Me.pbliboff)
        Me.Controls.Add(Me.mmorganS)
        Me.Controls.Add(Me.pbrot)
        Me.Controls.Add(Me.pbstudy)
        Me.Name = "Form3"
        Me.Text = "Form3"
        Me.TopMost = True
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gal1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gal2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gal3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbgal1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbgal2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbgal3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbliboff, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.liboff, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mmorganS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rot, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbrot, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.study, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbstudy, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_back As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents pbox4 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents pbox5 As PictureBox
    Friend WithEvents btn_exit1 As Button
    Friend WithEvents btn_f1 As Button
    Friend WithEvents btn_f2 As Button
    Friend WithEvents btn_floor3 As Button
    Friend WithEvents lbl_floor As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents pbox6 As PictureBox
    Friend WithEvents pbox7 As PictureBox
    Friend WithEvents btn_marble As Button
    Friend WithEvents pbox8 As PictureBox
    Friend WithEvents pbox9 As PictureBox
    Friend WithEvents pbox10 As PictureBox
    Friend WithEvents gal1 As PictureBox
    Friend WithEvents gal2 As PictureBox
    Friend WithEvents gal3 As PictureBox
    Friend WithEvents pbgal1 As PictureBox
    Friend WithEvents pbgal2 As PictureBox
    Friend WithEvents pbgal3 As PictureBox
    Friend WithEvents pbliboff As PictureBox
    Friend WithEvents liboff As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents mmorganS As PictureBox
    Friend WithEvents rot As PictureBox
    Friend WithEvents pbrot As PictureBox
    Friend WithEvents study As PictureBox
    Friend WithEvents pbstudy As PictureBox
End Class
