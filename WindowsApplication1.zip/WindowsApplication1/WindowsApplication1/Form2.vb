﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn1_Click_1(sender As Object, e As EventArgs) Handles btn1.Click
        My.Computer.Audio.Play("E:\SoftEng2017\Select.wav.")
        Dim form3 As New Form3
        form3.Show()
        Me.Hide()
    End Sub
End Class